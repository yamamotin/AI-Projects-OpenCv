from flask import render_template
from app import app

@app.route('/index')
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/inventory', defaults={'name':None})
@app.route('/inventory/<name>')
def inventory(name):
    pass

@app.route('/history')
def history():
    return render_template('base.html')

@app.route('/login')
def login():
    return render_template('base.html')