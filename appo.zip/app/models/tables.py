from app import db

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True)
    password = db.Column(db.String)
    email = db.Column(db.String, unique=True)
    categoria = db.Column(db.String)

    def __init__(self,username,password, email, categoria):
        self.username = username
        self.categoria = categoria
        self.password = password
        self.email = email
    def __repr__(self):
        return '<User %r>' % self.username

class History(db.Model):
    __tablename__ = 'PurchaseHistory'

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    id_user = db.Column(db.Integer, db.ForeignKey('id_user'))
    user = db.relationship('User', foreign_keys=id_user)

    def __init__(self,content,id_user):
        self.content = content
        self.id_user = id_user

    def __repr__(self):
        return '<Post %r>' % self.id

class Preco(db.Model):
    __tablename__  = 'values'

    id = db.Column(db.Integer)
    id_user = db.Column(db.Integer, db.ForeignKey('users.id'))
    valueout = db.Column(db.Integer)
    valuein = db.Column(db.Integer)